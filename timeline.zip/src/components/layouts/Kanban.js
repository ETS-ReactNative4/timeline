
import React from "react";

 

  function Kanban(props) {
    const { classes } = props;
  
    return (<div>
      <h2>VisaoKanban</h2>
    </div>)
  
  }
  

  export default Kanban;