
import React from "react";
import CardGrid from "./CardGrid"


const Timeline = (props) => (
  
     <CardGrid {...props} />
  

			
    
  );
  


  export default Timeline;